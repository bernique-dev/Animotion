using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Animotion {
    [Serializable]
    public class AnimotionTreeNodeEditor : AnimotionEditorWindowComponent {

        public NodeData node;
        public AnimotionTreeEditor animotionTreeEditor;
        public TreeData tree;

        public bool isSelected;
        public bool isMoved;

        private Vector2 lastPosition;

        public bool isLinkBeingCreated;

        public Rect rect {
            get {
                Vector2 rectangleSize = new Vector2(100, 35);
                return RectUtils.GetRect(new Vector2(Screen.width / 2, Screen.height / 2) + node.position, rectangleSize);
            }
        }

        public void SetValues(NodeData _node, AnimotionTreeEditor _animotionTreeEditor) {
            node = _node;
            animotionTreeEditor = _animotionTreeEditor;
            tree = _animotionTreeEditor.tree;
        }

        public override void Draw() {
            base.Draw();

            Handles.DrawSolidRectangleWithOutline(rect, isMoved ? Color.red: AnimotionTreeEditor.BACKGROUND_COLOR, isSelected ? Color.white : AnimotionTreeEditor.BORDER_COLOR);
            Handles.Label(rect.min, node.name);

            if (isLinkBeingCreated) {

                Vector2[] startSidesCenter = new Vector2[] {
                    rect.GetTopSideCenter(),
                    rect.GetDownSideCenter()
                };
                Vector2[] endPoints = new Vector2[0];
                Vector2 start = rect.center;
                Vector2 end = Event.current.mousePosition;

                DrawingUtils.FindClosestSegment(startSidesCenter, endPoints, ref start, ref end);
                Handles.DrawAAPolyLine(new Vector3[] { start, end });

                Vector3[] arrowPoints = DrawingUtils.GetArrowSummitPoints(start, end, 10, 7.5f);
                Handles.DrawAAConvexPolygon(arrowPoints);
            }
        }

        public override void ProcessEvent(Event e) {
            base.ProcessEvent(e);
            if (rect.Contains(e.mousePosition)) {
                if (e.isMouse) {
                    if (e.type == EventType.MouseDown && e.button == 0 && !isMoved) {
                        animotionTreeEditor.SelectNode(this, e.shift);
                    }
                    if ((e.type == EventType.MouseDrag && e.button == 0) && isSelected) {
                        isMoved = true;
                    }
                    // Right click for parameters
                    if (e.type == EventType.ContextClick) {
                        animotionTreeEditor.SelectNode(this, e.shift || isSelected);
                        GenericMenu menu = new GenericMenu();
                        menu.AddItem(new GUIContent("Create link"), false, () => StartLinkCreation());
                        menu.AddSeparator("");
                        menu.AddItem(new GUIContent("Delete"), false, () => animotionTreeEditor.DeleteNode(node.id));
                        menu.ShowAsContext();
                    }
                }

                if (e.type == EventType.DragPerform || e.type == EventType.DragUpdated) {
                    //Object hovering on Window
                    foreach (var obj in DragAndDrop.objectReferences) {
                        if (obj is AnimotionClipsData) {
                            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                            DragAndDrop.AcceptDrag();
                            isSelected = true;
                        }
                    }
                    // Object dropped
                    if (e.type == EventType.DragPerform) {
                        foreach (var obj in DragAndDrop.objectReferences) {
                            if (obj is AnimotionClipsData) node.animotionClipsData = obj as AnimotionClipsData;
                        }
                        isSelected = false;
                    }
                }
            }
            if (isMoved) {
                lastPosition = node.position;
                Vector2 newPosition = e.mousePosition - new Vector2(Screen.width, Screen.height) / 2;
                animotionTreeEditor.MoveSelectedNodes(newPosition - lastPosition);
            }
            if (e.type == EventType.MouseUp) {
                isMoved = false;
            }
        }

        public void StartLinkCreation() {
            isLinkBeingCreated = true;
        }

    }
}
