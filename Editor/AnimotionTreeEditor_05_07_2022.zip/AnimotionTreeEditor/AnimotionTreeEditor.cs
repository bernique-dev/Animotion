using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace Animotion {
    public class AnimotionTreeEditor : AnimotionEditorWindowComponent {

        /// <summary>
        /// Interface's borders' color (Dark Mode only)
        /// </summary>
        public static readonly Color BORDER_COLOR = new Color32(30, 30, 30, 255);

        public static readonly Color BACKGROUND_COLOR = new Color32(56/2, 56/2, 56*2, 255);


        /// <summary>
        /// Menubar's buttons' width
        /// </summary>
        public static readonly float MENUBAR_BUTTON_WIDTH = 55f;

        public TreeData tree;
        private List<AnimotionTreeNodeEditor> nodes;
        private List<AnimotionTreeLinkEditor> links;
        public List<AnimotionTreeNodeEditor> selectedNodes;

        [MenuItem("Animotion/Animotion Tree Editor")]
        public static void ShowWindow() {
            EditorWindow.GetWindow(typeof(AnimotionTreeEditor), false, "Animotion Tree Editor");
        }

        private void OnEnable() {
            NodeData.idCounter = tree.nodes.Count;
            DrawNodes();
            DrawLinks();
            foreach (AnimotionTreeNodeEditor node in nodes) {
                node.isLinkBeingCreated = false;
            }
        }

        private void OnGUI() {
            Draw();
            ProcessEvent(Event.current);
            Repaint();
        }

        public override void Draw() {
            Handles.BeginGUI();
            DrawMenuBar();


            string str = NodeData.idCounter + "\n";
            foreach (NodeData node in tree.nodes) {
                str += node.name + " (" + node.id + ")" + " (" + tree.nodeAndChildren[node].Count + ")\n";

            }

            foreach (AnimotionTreeLinkEditor animotionLinkNode in links) {
                animotionLinkNode.Draw();
                animotionLinkNode.ProcessEvent(Event.current);
            }
            foreach (AnimotionTreeNodeEditor animotionTreeNode in nodes) {
                animotionTreeNode.isSelected = selectedNodes.Contains(animotionTreeNode);
                animotionTreeNode.Draw();
                animotionTreeNode.ProcessEvent(Event.current);
            }

            str += "Nodes: " + nodes.Count + " | Links: " + links.Count;

            Handles.Label(new Vector2(3*Screen.width / 4, Screen.height / 4), str);
            Handles.EndGUI();
        }
        public void DrawMenuBar() {
            GUIStyle guiStyle = new GUIStyle();

            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            if (GUILayout.Button("Clear nodes", EditorStyles.toolbarButton)) {
                nodes = new List<AnimotionTreeNodeEditor>();
                tree.Clear();
                NodeData.idCounter = 0;
            }
            if (GUILayout.Button("Refresh display", EditorStyles.toolbarButton)) {
                OnEnable();
            }
            GUILayout.FlexibleSpace();
            if (tree) GUILayout.Label(tree.name);
            EditorGUILayout.EndHorizontal();
        }

        public override void ProcessEvent(Event e) {
            if (focusedWindow == this && mouseOverWindow == this) {
                if (e.isMouse) {
                    // Right click for parameters
                    if (IsNotContained(e.mousePosition)) {
                        if (e.type == EventType.ContextClick) {
                            if (IsLinkBeingCreated()) {
                                foreach (AnimotionTreeNodeEditor node in nodes) {
                                    node.isLinkBeingCreated = false;
                                }
                            } else {
                                GenericMenu menu = new GenericMenu();
                                menu.AddItem(new GUIContent("Create new state"), false, () => CreateNode(e.mousePosition));
                                menu.ShowAsContext();
                            }
                        }
                        if (e.type == EventType.MouseDown && e.button == 0) {
                            UnselectNodes();
                        }
                    }
                }
            }

            if (e.type == EventType.DragPerform || e.type == EventType.DragUpdated) {
                //Object hovering on Window
                foreach (var obj in DragAndDrop.objectReferences) {
                    if (obj is TreeData) {
                        DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                        DragAndDrop.AcceptDrag();
                    }
                }
                // Object dropped on timeline
                if (e.type == EventType.DragPerform) {
                    foreach (var obj in DragAndDrop.objectReferences) {
                        if (obj is TreeData) tree = obj as TreeData;
                    }
                }
            }
        }

        public void CreateNode(Vector2 mousePos) {
            NodeData newNode = new NodeData("node" + NodeData.idCounter, mousePos - new Vector2(Screen.width / 2, Screen.height / 2));
            tree.AddNode(newNode);
            AnimotionTreeNodeEditor atne = ScriptableObject.CreateInstance<AnimotionTreeNodeEditor>();
            atne.SetValues(newNode, this);
            nodes.Add(atne);
        }

        public void DeleteNode(int id) {
            tree.DeleteNode(id);
            DrawNodes();
            DrawLinks();
        }

        public void DeleteLink(AnimotionTreeLinkEditor link) {
            link.startNode.node.children.RemoveAll(id => id == link.endNode.node.id);
            if (link.bidirectional) link.endNode.node.children.RemoveAll(id => id == link.startNode.node.id);
            DrawLinks();
        }

        public void SelectNode(AnimotionTreeNodeEditor node, bool multipleSelect = false) {
            if (!multipleSelect || IsLinkBeingCreated()) {
                selectedNodes.Clear();
            }
            selectedNodes.Add(node);
            if (IsLinkBeingCreated()) {
                AnimotionTreeNodeEditor linkAuthor = GetLinkCreationAuthor();
                linkAuthor.isLinkBeingCreated = false;
                linkAuthor.node.children.Add(node.node.id);
                SelectNode(linkAuthor);
                DrawLinks();
            }
        }

        public void CreateLink(AnimotionTreeNodeEditor start, AnimotionTreeNodeEditor end) {
            AnimotionTreeLinkEditor atle = ScriptableObject.CreateInstance<AnimotionTreeLinkEditor>();
            atle.SetValues(start, end, this, tree.nodeAndChildren[end.node].Contains(start.node));
            links.Add(atle);
        }

        public void CreateLink(int startId, int endId) {
            CreateLink(nodes.Find(n => n.node.id == startId), nodes.Find(n => n.node.id == endId));
        }

        public bool IsLinkBeingCreated() {
            return GetLinkCreationAuthor();
        }
        public AnimotionTreeNodeEditor GetLinkCreationAuthor() {
            return nodes.Find(node => node.isLinkBeingCreated);
        }

        public void MoveSelectedNodes(Vector2 delta) {
            foreach (AnimotionTreeNodeEditor node in selectedNodes) {
                node.node.position += delta;
            }
        }

        public void UnselectNodes() {
            foreach (AnimotionTreeNodeEditor node in selectedNodes) {
                node.isSelected = false;
            }
            selectedNodes.Clear();
        }

        public void DrawNodes() {
            nodes = new List<AnimotionTreeNodeEditor>();
            foreach (NodeData node in tree.nodes) {
                AnimotionTreeNodeEditor atne = ScriptableObject.CreateInstance<AnimotionTreeNodeEditor>();
                atne.SetValues(node, this);
                nodes.Add(atne);
            }
        }

        public void DrawLinks() {
            links = new List<AnimotionTreeLinkEditor>();
            foreach (NodeData node in tree.nodes) {
                foreach (NodeData child in tree.nodeAndChildren[node]) {
                    if (!links.Find(l => ((l.startNode.node == node && l.endNode.node == child) || (l.startNode.node == child && l.endNode.node == node)))) {
                        CreateLink(node.id, child.id);
                    }
                }
            }
        }

        public bool IsNotContained(Vector2 position) {
            return !IsContainedByNode(position) && !IsContainedByLink(position);
        }

        public bool IsContainedByNode(Vector2 position) {
            return nodes.Find(atne => atne.rect.Contains(position));
        }
        public bool IsContainedByLink(Vector2 position) {
            return links.Find(atle => atle.Contains(position));
        }
    }
}


