using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


namespace Animotion {
    [Serializable]
    public class AnimotionTreeLinkEditor : AnimotionEditorWindowComponent {

        public AnimotionTreeEditor animotionTreeEditor;

        public AnimotionTreeNodeEditor startNode;
        public AnimotionTreeNodeEditor endNode;
        public bool bidirectional;

        private Vector2 start; 
        private Vector2 end;

        public float detectionRectWidth = 5;
        private bool clickContained;

        public void SetValues(AnimotionTreeNodeEditor _start, AnimotionTreeNodeEditor _end, AnimotionTreeEditor _animotionTreeEditor, bool _bidirectional = false) {
            startNode = _start;
            endNode = _end;
            animotionTreeEditor = _animotionTreeEditor;
            bidirectional = _bidirectional;
        }

        public override void Draw() {
            base.Draw();
            if (startNode && endNode) {
                Handles.color = Color.white;
                start = startNode.rect.center;
                end = endNode.rect.center;
                Vector2[] startSidesCenter = new Vector2[] {
                    startNode.rect.GetTopSideCenter(),
                    startNode.rect.GetDownSideCenter()
                };

                Vector2[] endSidesCenter = new Vector2[] {
                    endNode.rect.GetTopSideCenter(),
                    endNode.rect.GetDownSideCenter()
                };

                DrawingUtils.FindClosestSegment(startSidesCenter, endSidesCenter, ref start, ref end);
                Handles.DrawAAPolyLine(new Vector3[] { start, end });

                Vector3[] arrowPoints = DrawingUtils.GetArrowSummitPoints(start,end,10,7.5f);
                if (!bidirectional) Handles.DrawAAConvexPolygon(arrowPoints);


            }
        }

        public override void ProcessEvent(Event e) {
            base.ProcessEvent(e);
            clickContained = Contains(e.mousePosition);
            if (Contains(e.mousePosition) && !animotionTreeEditor.IsContainedByNode(e.mousePosition)) {
                if (e.type == EventType.ContextClick) {
                    GenericMenu menu = new GenericMenu();
                    menu.AddItem(new GUIContent("Delete"), false, () => animotionTreeEditor.DeleteLink(this));
                    menu.ShowAsContext();
                }
            }
        }

        public bool Contains(Vector2 position) {
            float widthDotProduct = Mathf.Abs(Vector2.Dot(position - start, Vector2.Perpendicular((end - start).normalized)));
            float heightDotProduct = Vector2.Dot(position - start, (end - start).normalized);
            return widthDotProduct <= detectionRectWidth && heightDotProduct >= 0 && heightDotProduct <= Vector2.Distance(start, end);
        }

    }
}

